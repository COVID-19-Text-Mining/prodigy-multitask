print ("Core statistics imported..")
