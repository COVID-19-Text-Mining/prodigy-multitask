## init for embedding visualization
